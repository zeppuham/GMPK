﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using System.Windows.Forms;
public partial class AdminPortal : System.Web.UI.Page
{
    SqlConnection sc = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        // Connect to DataBase
        try
        {
            sc.ConnectionString = @"Server=LocalHost;Database=GroupProject;Trusted_Connection=Yes;";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error" + ex.Message);
        }
    }
    protected void btnAdd_ServerClick(object sender, EventArgs e)
    {
        String email = txtLeadEmail.Value.ToString();

        sc.Open();
        // check to validate entered email exists in db
        SqlCommand checkEmail = new SqlCommand("SELECT COUNT(*) FROM MEMBER WHERE EMAIL = @email");
        checkEmail.Connection = sc;
        checkEmail.Parameters.AddWithValue("@email", email);
        int check = (int)checkEmail.ExecuteScalar();
        if (check == 0)
        {
            MessageBox.Show("Error - Email Does Not Exist");
            return;
        }

        // update member table to make volunteer teamLead
        SqlCommand update = new SqlCommand("update member set TeamLead = 1 where email = @email", sc);
        update.Parameters.AddWithValue("@email", email);
        update.ExecuteNonQuery();

        MessageBox.Show("Success! You have promoted the user to Team Lead status.");
        Response.Redirect("LeadPortal.aspx");
        sc.Close();
    }
    protected void btnRemove_ServerClick(object sender, EventArgs e)
    {
        String email = txtLeadEmail.Value.ToString();

        sc.Open();
        // check to validate entered email exists in db
        SqlCommand checkEmail = new SqlCommand("SELECT COUNT(*) FROM MEMBER WHERE EMAIL = @email");
        checkEmail.Connection = sc;
        checkEmail.Parameters.AddWithValue("@email", email);
        int check = (int)checkEmail.ExecuteScalar();
        if (check == 0)
        {
            MessageBox.Show("Error - Email Does Not Exist");
            return;
        }

        // update member table to make volunteer teamLead
        SqlCommand update = new SqlCommand("update member set TeamLead = 0 where email = @email", sc);
        update.Parameters.AddWithValue("@email", email);
        update.ExecuteNonQuery();

        MessageBox.Show("Success! You have removed the user from team lead status.");
        Response.Redirect("LeadPortal.aspx");
        sc.Close();
    }
}