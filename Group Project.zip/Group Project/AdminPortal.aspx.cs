﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using System.Windows.Forms;
public partial class AdminPortal : System.Web.UI.Page
{
    SqlConnection sc = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        // Connect to DataBase
        try
        {
            sc.ConnectionString = @"Server=LocalHost;Database=GroupProject;Trusted_Connection=Yes;";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error" + ex.Message);
        }
    }
    protected void btnAdd_ServerClick(object sender, EventArgs e)
    {
        // Test is 
        if (txtLeadEmail.Value == null)
        {
            MessageBox.Show("Error: Email Address is required");
            return;
        }


    }
}