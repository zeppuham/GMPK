﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Security.Cryptography;
using System.IO;
// Change Framework version to 4.0.0 to import reference below
using System.Windows.Forms;


public partial class Hours_Log : System.Web.UI.Page
{
    SqlConnection sc = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        // Connect to DataBase
        try
        {
            sc.ConnectionString = @"Server=LAPTOP-PHM83N4S\sqlexpress;Database=GroupProject;Trusted_Connection=Yes;";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error" + ex.Message);
            return;
        }
        // retrieve current user's email
        String email = System.Web.HttpContext.Current.User.Identity.Name;
        SqlCommand cmd = new SqlCommand();
        SqlDataReader reader = default(SqlDataReader);

        sc.Open();
        cmd.Connection = sc;
        
        // get user ID
        SqlCommand user = new SqlCommand("Select ID from member where email = @email");
        user.Connection = sc;
        user.Parameters.AddWithValue("@email", email);
        int userID = (int)user.ExecuteScalar();
        cmd.CommandText = "SELECT convert(varchar(10), cast([DateWorked] as date), 101) as Date, format(cast([StartTime] as datetime), 'hh:mm tt') as StartTime, format(cast([EndTime]as datetime),'hh:mm tt')as EndTime FROM [HoursLogged] where ID = @ID";
        cmd.Parameters.AddWithValue("@ID", ID);
        
        // bind data to gridView
        reader = cmd.ExecuteReader();
        grdLogHours.DataSource = reader;
        grdLogHours.DataBind();

        sc.Close();

    }
}