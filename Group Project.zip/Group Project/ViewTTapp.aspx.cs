﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using System.Windows.Forms;

public partial class ViewTTapp : System.Web.UI.Page
{
    SqlConnection sc = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        // Connect to DataBase
        try
        {
            sc.ConnectionString = @"Server=LocalHost;Database=GroupProject;Trusted_Connection=Yes;";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error" + ex.Message);
        }
        // retrieve applicants email
        string email = Request["Email"].ToString();
        sc.Open();

        // populate basic applicant information
        using (SqlCommand cmd = new SqlCommand("SELECT FirstName, LastName, Phone, Street, CityCounty, State_, ZipCode, dateofBirth, EmergencyContactFirstName, EmergencyContactLastName, EmergencyContactRelationship, EmergencyContactEmail, EmergencyContactPhone, Allergies, Limitations From Member where Email = @Email", sc))
        {
            cmd.Parameters.AddWithValue("@email", email);

            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    // test if value is null before displaying 
                    if (reader[0] != DBNull.Value)
                    {
                        txtProfFName.Value = reader[0].ToString();
                    }
                    if (reader[1] != DBNull.Value)
                    {
                        txtProfLName.Value = reader[1].ToString();
                    }
                    if (reader[2] != DBNull.Value)
                    {
                        txtProfPhone.Value = reader[2].ToString();
                    }
                    if (reader[3] != DBNull.Value)
                    {
                        txtProfStreet.Value = reader[3].ToString();
                    }
                    if (reader[4] != DBNull.Value)
                    {
                        txtProfCity.Value = reader[4].ToString();
                    }
                    if (reader[5] != DBNull.Value)
                    {
                        txtProfState.Value = reader[5].ToString();
                    }
                    if (reader[6] != DBNull.Value)
                    {
                        txtProfZip.Value = reader[6].ToString();
                    }
                    if (reader[7] != DBNull.Value)
                    {
                        txtProfDOB.Value = reader[7].ToString();
                    }
                    if (reader[8] != DBNull.Value)
                    {
                        txtProfEmFName.Value = reader[8].ToString();
                    }
                    if (reader[9] != DBNull.Value)
                    {
                        txtProfEmLName.Value = reader[9].ToString();
                    }
                    if (reader[10] != DBNull.Value)
                    {
                        txtProfEmRelation.Value = reader[10].ToString();
                    }
                    if (reader[11] != DBNull.Value)
                    {
                        txtProfEmEmail.Value = reader[11].ToString();
                    }
                    if (reader[12] != DBNull.Value)
                    {
                        txtProfEmPhone.Value = reader[12].ToString();
                    }
                    if (reader[13] != DBNull.Value)
                    {
                        txtProfAllergies.Value = reader[13].ToString();
                    }
                    if (reader[14] != DBNull.Value)
                    {
                        txtProfLimitations.Value = reader[14].ToString();
                    }
                }
            }
        }
        // populate application specific fields
        using (SqlCommand cmd1 = new SqlCommand("select interest1, interest2, interest3, interest4 from treatment_team_app where userEmail = @email", sc))
        {
            cmd1.Parameters.AddWithValue("@email", email);

                using (var reader = cmd1.ExecuteReader())
                {
                 while (reader.Read())
                   {
                       txtInterest1.Value = reader[0].ToString();
                       txtInterest2.Value = reader[1].ToString();
                       txtInterest3.Value = reader[2].ToString();
                       txtInterest4.Value = reader[3].ToString();
                   }
                }
             }
        sc.Close();
    }
    protected void btnApprove_ServerClick(object sender, EventArgs e)
    {
        string email = Request["Email"].ToString();
        sc.Open();
        // update db to make applicant a volunteer
        SqlCommand approve = new SqlCommand("Update member set Volunteer = 1 where email = @email", sc);
        approve.Parameters.AddWithValue("@email", email);
        approve.ExecuteNonQuery();

        // change application status to accepted
        SqlCommand accepted = new SqlCommand("update treatment_team_app set accepted = 'Approved' where userEmail = @email", sc);
        accepted.Parameters.AddWithValue("@email", email);
        accepted.ExecuteNonQuery();

        MessageBox.Show("Success! The approved user can now log in as a volunteer.");
        Response.Redirect("LeadPortal.aspx");
        sc.Close();
    }
    protected void btnReject_ServerClick(object sender, EventArgs e)
    {
        string email = Request["Email"].ToString();
        sc.Open();
        // change application status to rejected
        SqlCommand accepted = new SqlCommand("update treatment_team_app set accepted = 'Rejected' where userEmail = @email", sc);
        accepted.Parameters.AddWithValue("@email", email);
        accepted.ExecuteNonQuery();

        MessageBox.Show("Success! The application has been rejected.");
        Response.Redirect("LeadPortal.aspx");
        sc.Close();


    }
 }
