﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using System.Windows.Forms;

public partial class VolunteerPortal : System.Web.UI.Page
{
    SqlConnection sc = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        // Connect to DataBase
        try
        {
            sc.ConnectionString = @"Server=LAPTOP-PHM83N4S\sqlexpress;Database=GroupProject;Trusted_Connection=Yes;";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error" + ex.Message);
        }
        // retrieve current user's email
        String email = System.Web.HttpContext.Current.User.Identity.Name;

        
    }

    protected void btnSubmit_ServerClick(object sender, EventArgs e)
    {
        // retrieve current user's email
        String email = System.Web.HttpContext.Current.User.Identity.Name;

        if (Request.Form["txtDate"].ToString() == null || Request.Form["txtStartTime"].ToString() == null || Request.Form["txtEndTime"].ToString() == null)
        {
            MessageBox.Show("Hours Not Recorded - Please Fill Out All Fields");
            return;
        }

        // get users inputs
        String date = Request.Form["txtDate"].ToString();
        String start = Request.Form["txtStartTime"].ToString();
        String end =  Request.Form["txtEndTime"].ToString();
            
        //insert to database
        sc.Open();
        SqlCommand insert = new SqlCommand();
        insert.Connection = sc;

        // get current user's ID
        SqlCommand user =  new SqlCommand("Select ID from member where email = @email");
        user.Connection = sc;
        user.Parameters.AddWithValue("@email",email);
        int userID = (int)user.ExecuteScalar();


        insert.CommandText = "INSERT into HoursLogged VALUES (@ID, @Date, @StartTime, @EndTime)";
        insert.Parameters.AddWithValue("@ID", userID);
        insert.Parameters.AddWithValue("@Date", date);
        insert.Parameters.AddWithValue("@StartTime", start);
        insert.Parameters.AddWithValue("@EndTime", end);
        userID++;

        insert.ExecuteScalar();

        sc.Close();
        MessageBox.Show("Hours Recorded Successfully!");
        Response.Redirect("VolunteerPortal.aspx");
    }
}