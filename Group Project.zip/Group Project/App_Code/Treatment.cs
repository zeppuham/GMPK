﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Treatment
/// </summary>
public class Treatment
{
	public Treatment()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}