﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for AnimalCare
/// </summary>
public class AnimalCare
{
	public AnimalCare()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}