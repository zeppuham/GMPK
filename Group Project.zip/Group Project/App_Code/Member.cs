﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
// Change Framework version to 4.0.0 to import reference below
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Data.Entity;

public class Member
{
    // data fields
    private String fName;
    private String lName;
    private String address;
    private String city;
    private String state;
    private int zip;
    private String phoneNumber;
    private String DoB;
    private String email;
    private String password;
    private String emergencyPhone;
    private String emergencyFirstName;
    private String emergencyLastName;
    private String emergencyEmail;
    private String relationship;
    private String salt;
    private int vol;
    private int teamLead;
    private int admin;
    public static int count = 0;
    private int ID;
    // constructors
    public Member(String fname, String lname, String password, String email, String salt)
    {
        setFName(fname);
        setLName(lname);
        setEmail(email);
        setPassword(password);
        setSalt(salt);
        vol = 0;
        teamLead = 0;
        admin = 0;
        setID(count);
        count++;
    }

    public Member(String fname, String lname, String address,
                    String city, String state, int zip, String phoneNumber, String DoB
                     , String email, String password,
                      String emergencyFirstName, String EmergencyLastName, String emergencyPhone, String emergencyEmail, String relationship)
    {
        setFName(fname);
        setLName(lname);
        setAddress(address);
        setCity(city);
        setState(state);
        setZip(zip);
        setPhone(phoneNumber);
        setDoB(DoB);
        setEmail(email);
        setPassword(password);
        setEmergencyFirstName(emergencyFirstName);
        setEmergencyLastName(EmergencyLastName);
        setEmergencyPhone(emergencyPhone);
        setEmergencyEmail(emergencyEmail);
        setRelationship(relationship);
    }

    // setter methods
    public void setFName(String fname)
    {
        this.fName = fname;
    }
    public void setLName(String lname)
    {
        this.lName = lname;
    }
    public void setAddress(String address)
    {
        this.address = address;
    }
    public void setCity(String city)
    {
        this.city = city;
    }
    public void setState(String state)
    {
        this.state = state;
    }
    public void setZip(int zip)
    {
        this.zip = zip;
    }
    public void setPhone(String phoneNumber)
    {
        this.phoneNumber = phoneNumber;
    }
    public void setDoB(String DoB)
    {
        this.DoB = DoB;
    }
    public void setEmail(String email)
    {
        this.email = email;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }
    public void setSalt(String salt)
    {
        this.salt = salt;
    }
    public void setID(int ID)
    {
        this.ID = ID;
    }
    public void setEmergencyFirstName(String emergencyFirstName)
    {
        this.emergencyFirstName = emergencyFirstName;
    }
    public void setEmergencyLastName(String emergencyLastName)
    {
        this.emergencyLastName = emergencyLastName;
    }
    public void setEmergencyPhone(String emergencyPhone)
    {
        this.emergencyPhone = emergencyPhone;
    }
    public void setEmergencyEmail(String emergencyEmail)
    {
        this.emergencyEmail = emergencyEmail;
    }
    public void setRelationship(String relationship)
    {
        this.relationship = relationship;
    }

    // getter methods
    public String getFName()
    {
        return this.fName;
    }
    public String getLName()
    {
        return this.lName;
    }
    public String getAddress()
    {
        return this.address;
    }
    public String getCity()
    {
        return this.city;
    }
    public String getState()
    {
        return this.state;
    }
    public int getZip()
    {
        return this.zip;
    }
    public String getPhone()
    {
        return this.phoneNumber;
    }
    public String getDoB()
    {
        return this.DoB;
    }
    public String getEmail()
    {
        return this.email;
    }
    public String getPassword()
    {
        return this.password;
    }
    public String getSalt()
    {
        return this.salt;
    }
    public int getVol()
    {
        return this.vol;
    }
    public int getTeamLead()
    {
        return this.teamLead;
    }
    public int getAdmin()
    {
        return this.admin;
    }
    public String getEmergencyFirstName()
    {
        return this.emergencyFirstName;
    }
    public String getEmergencyLastName()
    {
        return this.emergencyLastName;
    }
    public String getEmergencyPhone()
    {
        return this.emergencyPhone;
    }
    public String getEmergencyEmail()
    {
        return this.emergencyEmail;
    }
    public String getRelationship()
    {
        return this.relationship;
    }
    public int getCount()
    {
        return count;
    }

    // current user method
    public static Member Instance
    {
        return (Member)Session[
    }
}