﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class Volunteer
{
    // data fields
    private String fName;
    private String lName;
    private String address;
    private String city;
    private String state;
    private int zip;
    private String phoneNumber;
    private String DoB;
    private String email;
    private String password;
    private String emergencyPhone;
    private String emergencyFirstName;
    private String emergencyLastName;
    private String emergencyEmail;
    private String relationship;

    // constructor
	public Volunteer(String fname, String lname, String address, 
                    String city, String state, int zip, String phoneNumber, String DoB
                     , String email, String password, 
                      String emergencyFirstName, String EmergencyLastName, String emergencyPhone, String emergencyEmail, String relationship)
	{
        setFName(fname);
        setLName(lname);
        setAddress(address);
        setCity(city);
        setState(state);
        setZip(zip);
        setPhone(phoneNumber);
        setDoB(DoB);
        setEmail(email);
        setPassword(password);
        setEmergencyFirstName(emergencyFirstName);
        setEmergencyLastName(EmergencyLastName);
        setEmergencyPhone(emergencyPhone);
        setEmergencyEmail(emergencyEmail);
        setRelationship(relationship);
	}
    
    // setter methods
    public void setFName(String fname)
    {
        this.fName = fname;
    }
    public void setLName(String lname)
    {
        this.lName = lname;
    }
    public void setAddress(String address)
    {
        this.address = address;
    }
    public void setCity(String city)
    {
        this.city = city;
    }
    public void setState(String state)
    {
        this.state = state;
    }
    public void setZip(int zip)
    {
        this.zip = zip;
    }
    public void setPhone(String phoneNumber)
    {
        this.phoneNumber = phoneNumber;
    }
    public void setDoB(String DoB)
    {
        this.DoB = DoB;
    }
    public void setEmail(String email)
    {
        this.email = email;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }
    public void setEmergencyFirstName(String emergencyFirstName)
    {
        this.emergencyFirstName = emergencyFirstName;
    }
    public void setEmergencyLastName(String emergencyLastName)
    {
        this.emergencyLastName = emergencyLastName;
    }
    public void setEmergencyPhone(String emergencyPhone)
    {
        this.emergencyPhone = emergencyPhone;
    }
    public void setEmergencyEmail(String emergencyEmail)
    {
        this.emergencyEmail = emergencyEmail;
    }
    public void setRelationship(String relationship)
    {
        this.relationship = relationship;
    }

    // getter methods
    public String getFName()
    {
        return this.fName;
    }
    public String getLName()
    {
        return this.lName;
    }
    public String getAddress()
    {
        return this.address;
    }
    public String getCity()
    {
        return this.city;
    }
    public String getState()
    {
        return this.state;
    }
    public int getZip()
    {
        return this.zip;
    }
    public String getPhone()
    {
        return this.phoneNumber;
    }
    public String getDoB()
    {
        return this.DoB;
    }
    public String getEmail()
    {
        return this.email;
    }
    public String getPassword()
    {
        return this.password;
    }
    public String getEmergencyFirstName()
    {
        return this.emergencyFirstName;
    }
    public String getEmergencyLastName()
    {
        return this.emergencyLastName;
    }
    public String getEmergencyPhone()
    {
        return this.emergencyPhone;
    }
    public String getEmergencyEmail()
    {
        return this.emergencyEmail;
    }
    public String getRelationship()
    {
        return this.relationship;
    }
}