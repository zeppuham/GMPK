﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class Volunteer
{
    // data fields
    private String fName;
    private String lName;
    private String address;
    //private String address1;
    private String city;
    private String state;
    private int zip;
    private String phoneNumber;
    private String DoB;
    private int accountID;
    private String email;
    private String password;

    // constructor
	public Volunteer(String fname, String lname, String address, 
                    String city, String state, int zip, String phoneNumber, String DoB
                     , int accountID, String email, String password)
	{
        setFName(fname);
        setLName(lname);
        setAddress(address);
        setCity(city);
        setState(state);
        setZip(zip);
        setPhone(phoneNumber);
        setDoB(DoB);
        setAccountID(accountID);
        setEmail(email);
        setPassword(password);
	}
    
    // setter methods
    public void setFName(String fname)
    {
        this.fName = fname;
    }
    public void setLName(String lname)
    {
        this.lName = lname;
    }
    public void setAddress(String address)
    {
        this.address = address;
    }
    public void setCity(String city)
    {
        this.city = city;
    }
    public void setState(String state)
    {
        this.state = state;
    }
    public void setZip(int zip)
    {
        this.zip = zip;
    }
    public void setPhone(String phoneNumber)
    {
        this.phoneNumber = phoneNumber;
    }
    public void setDoB(String DoB)
    {
        this.DoB = DoB;
    }
    public void setAccountID(int accountID)
    {
        this.accountID = accountID;
    }
    public void setEmail(String email)
    {
        this.email = email;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }
    
    // getter methods
    public String getFName()
    {
        return this.fName;
    }
    public String getLName()
    {
        return this.lName;
    }
    public String getAddress()
    {
        return this.address;
    }
    public String getCity()
    {
        return this.city;
    }
    public String getState()
    {
        return this.state;
    }
    public int getZip()
    {
        return this.zip;
    }
    public String getPhone()
    {
        return this.phoneNumber;
    }
    public String getDoB()
    {
        return this.DoB;
    }
    public int getAccountID()
    {
        return this.accountID;
    }
    public String getEmail()
    {
        return this.email;
    }
    public String getPassword()
    {
        return this.password;
    }
}