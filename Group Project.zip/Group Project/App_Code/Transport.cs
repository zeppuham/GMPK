﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using System.Windows.Forms;


public class Transport
{
    // data fields
    String availability;
    String travel;
    String rabies;
    String capture;
    String acknowledge;
    String email;
    
    // constructor
	public Transport(String availability, String travel, String rabies, String capture, String acknowledge, String email)
	{
		
	}
    //setters
    public void setAvailability(String availability)
    {
        this.availability = availability;
    }
    public void setTravel(String travel)
    {
        this.travel = travel;
    }
    public void setRabies(String rabies)
    {
        this.rabies = rabies;
    }
    public void setCapture(String capture)
    {
        this.capture = capture;
    }
    public void setAcknowledge(String acknowledge)
    {
        this.acknowledge = acknowledge;
    }
    public void setEmail(String email)
    {
        this.email = email;
    }
    // getter methods
    public String getAvailability()
    {
        return this.availability;
    }
    public String getTravel()
    {
        return this.travel;
    }
    public String getRabies()
    {
        return this.rabies;
    }
    public String getCapture()
    {
        return this.capture;
    }
    public String getAcknowledge()
    {
        return this.acknowledge;
    }
    public String getEmail()
    {
        return this.email;
    }


}