﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Transport
/// </summary>
public class Transport
{
	public Transport()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}