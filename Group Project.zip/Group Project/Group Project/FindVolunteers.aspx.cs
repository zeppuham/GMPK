﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Security.Cryptography;
using System.IO;
// Change Framework version to 4.0.0 to import reference below
using System.Windows.Forms;

public partial class FindVolunteers : System.Web.UI.Page
{
    SqlConnection sc = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        // Connect to DataBase
        try
        {
            sc.ConnectionString = @"Server=LAPTOP-PHM83N4S\sqlexpress;Database=GroupProject;Trusted_Connection=Yes;";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error" + ex.Message);
            return;
        }


    }
    protected void btnShowVolunteers_ServerClick(object sender, EventArgs e)
    {
        //get inputs from first filter
        String filter1 = ddlFilter1.Value.ToString();
        String input1 = txtFilter1.Value.ToString();
        String filter2;
        String input2;
       

        SqlCommand cmd = new SqlCommand();
        SqlDataReader reader = default(SqlDataReader);
        try
        {

            sc.Open();
            cmd.Connection = sc;
            if ((Request.Form["ddlFilter2"] == "" && Request.Form["ddlFilter3"] == "") && (Request.Form["txtFilter2"] == "" && Request.Form["txtFilter3"] == ""))
            {
                cmd.CommandText = "select email, firstName as [First Name], lastName as [Last Name]  from member where " + filter1 + " = @input1 AND volunteer = 1";
                cmd.Parameters.AddWithValue("@input1", input1);
                reader = cmd.ExecuteReader();
                grdShowVolunteers.DataSource = reader;
                grdShowVolunteers.DataBind();

            }
            else if (Request.Form["ddlFilter3"] == "" && Request.Form["txtFilter3"] == "")
            {
                filter2 = ddlFilter2.Value.ToString();
                input2 = txtFilter2.Value.ToString();

                cmd.CommandText = "select email, firstName as [First Name], lastName as [Last Name]  from member where " + filter1 + " = @input1 AND " + filter2 + " = @input2  AND volunteer = 1";
                cmd.Parameters.AddWithValue("@input1", input1);
                cmd.Parameters.AddWithValue("@input2", input2);
                reader = cmd.ExecuteReader();
                grdShowVolunteers.DataSource = reader;
                grdShowVolunteers.DataBind();
            }
            else
            {
                filter2 = ddlFilter2.Value.ToString();
                input2 = txtFilter2.Value.ToString();
                String filter3 = ddlFilter3.Value.ToString();
                String input3 = txtFilter3.Value.ToString();

                cmd.CommandText = "select email, firstName as [First Name], lastName as [Last Name]  from member where " + filter1 + " = @input1 AND " + filter2 + " = @input2 AND " + filter3 + " = @input3 AND volunteer = 1";
                cmd.Parameters.AddWithValue("@input1", input1);
                cmd.Parameters.AddWithValue("@input2", input2);
                cmd.Parameters.AddWithValue("@input3", input3);
                reader = cmd.ExecuteReader();
                grdShowVolunteers.DataSource = reader;
                grdShowVolunteers.DataBind();
            }
        }
        catch
        {
            MessageBox.Show("Input Error: First filter is required, fill out the others in order as needed");
        }
    }
}