﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Security.Cryptography;
using System.IO;

// Change Framework version to 4.0.0 to import reference below
using System.Windows.Forms;


public class Outreach
{   // data fields
    // get current user email
    String email; 
    String availability;
    String interest1;
    String interest2;
    String interest3;
    String interest4;

	public Outreach(String availability, String interest1, String interest2, String interest3, String interest4, String email)
	{
        setAvailability(availability);
        setInterest1(interest1);
        setInterest2(interest2);
        setInterest3(interest3);
        setInterest4(interest4);
        setEmail(email);
	}
    // setter methods
    public void setAvailability(String availability)
    {
        this.availability = availability;
    }
    public void setInterest1(String interest1)
    {
        this.interest1 = interest1;
    }
    public void setInterest2(String interest2)
    {
        this.interest2 = interest2;
    }
    public void setInterest3(String interest3)
    {
        this.interest3 = interest3;
    }
    public void setInterest4(String interest4)
    {
        this.interest4 = interest4;
    }
    public void setEmail(String email)
    {
        this.email = email;
    }
    // getter methods
    public String getAvailability()
    {
         return this.availability;
    }
    public String getInterest1()
    {
        return this.interest1;
    }
    public String getInterest2()
    {
        return this.interest2;
    }
    public String getInterest3()
    {
        return this.interest3;
    }
    public String getInterest4()
    {
        return this.interest4;
    }
    // getter methods
    public String getEmail()
    {
        return this.email;
    }
}