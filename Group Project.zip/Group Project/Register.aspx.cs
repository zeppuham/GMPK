﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
// Change Framework version to 4.0.0 to import reference below
using System.Windows.Forms;

public partial class Register : System.Web.UI.Page
{
    SqlConnection sc = new SqlConnection();

    protected void Page_Load(object sender, EventArgs e)
    {
        // Connect to DataBase
        try
        {
            sc.ConnectionString = @"Server=LocalHost\SQLEXPRESS;Database=GroupProject;Trusted_Connection=Yes;";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error" + ex.Message);
        }
    }
    protected void btnRegister_ServerClick(object sender, EventArgs e)
    {
        // create variables 
        String fname = Request.Form["txtFirstName"];
        String lname = Request.Form["txtLastName"];
        String email = Request.Form["txtEmail"];
        String password = Request.Form["txtPassword"];
        String confirmPass = Request.Form["txtConfirmPassword"];
        String phone = Request.Form["txtPhone"];
        String address = Request.Form["txtStreet"];
        String cityCounty = Request.Form["txtCity"];
        String state = ddlState.Value.ToString();
        String zip = Request.Form["txtZipCode"];
        int zipCode = Convert.ToInt32(zip);
        String DoB = Request.Form["txtDoB"];
        String emergConFName = Request.Form["txtEmergConFirstName"];
        String emergConLName = Request.Form["txtEmergConLastName"];
        String emergConPhone = Request.Form["txtEmergConNumber"];
        String emergConEmail = Request.Form["txtEmergConEmail"];
        String emergConRelationship = txtEmergConRelationship.Value.ToString();

        // NOTE: Have not created variables for medical information section
        
        // Test if email is entered in valid format
        if (!email.Contains("@"))
        {
            MessageBox.Show("Error: Invalid Email Entered");
            return;
        }
        // Variables to test if password contains upperCase, lowerCase, and Number
        bool containsUpper = false;
        bool containsLower = false;
        bool containsNumber = false;
        for (int i = 0; i < password.Length; i++)
        {
            if (char.IsUpper(password[i]))
            {
                containsUpper = true;
            }
            if (char.IsLower(password[i]))
            {
                containsLower = true;
            }
            if (char.IsNumber(password[i]))
            {
                containsNumber = true;
            }
        }
        // test if password meets requirements
        if (password.Length < 6 || containsUpper == false || containsLower == false || containsNumber == false)
        {
            MessageBox.Show("Error: Password does not meet requirements");
            return;
        }
        // test is passwords are the same
        if (password != confirmPass)
        {
            MessageBox.Show("Error: Passwords do not match - Please try again");
            return;
        }

        // create new Volunteer class object
        Volunteer newVolunteer = new Volunteer(fname, lname, address, cityCounty, state, zipCode, phone, DoB, email, password, emergConFName, emergConLName, emergConPhone, emergConEmail, emergConRelationship);
        
        // Use new Volunteer class object to insert into database
        sc.Open();
        SqlCommand insert = new SqlCommand();
        insert.Connection = sc;

        // check if email already exists in db
        SqlCommand checkEmail = new SqlCommand("SELECT COUNT(*) FROM PERSON WHERE EMAIL = @email");
        checkEmail.Connection = sc;
        checkEmail.Parameters.AddWithValue("@email", email);
        int check = (int)checkEmail.ExecuteScalar();
        if (check != 0)
        {
            MessageBox.Show("Error - Email Already Exists");
            return;
        }

        // insert newVolunteer info into Volunteer db table
        insert.CommandText = "INSERT INTO Person (Password_, FirstName, LastName, Email, Phone, DateofBirth, StreetAddress, CityCounty, StateAbb, ZipCode, EmergencyContactFirstName, EmergencyContactLastName, EmergencyContactEmail, EmergencyContactPhone, EmergencyContactRelationship)";
        insert.CommandText += "VALUES (@password, @fname, @lname, @email, @phone, @DoB, @address, @city, @state, @zip, @emergencyFName, @emergencyLName,  @emergencyEmail, @emergencyPhone, @relationship)";
        // need DoB, remove login, address one line?, need countryabb?, emergency contact name/relationship

        // parameterize insert statement
        insert.Parameters.AddWithValue("@password", newVolunteer.getPassword());
        insert.Parameters.AddWithValue("@fname", newVolunteer.getFName());
        insert.Parameters.AddWithValue("@lname", newVolunteer.getLName());
        insert.Parameters.AddWithValue("@email", newVolunteer.getEmail());
        insert.Parameters.AddWithValue("@address", newVolunteer.getAddress());
        insert.Parameters.AddWithValue("@city", newVolunteer.getCity());
        insert.Parameters.AddWithValue("@state", newVolunteer.getState());
        insert.Parameters.AddWithValue("@zip", newVolunteer.getZip());
        insert.Parameters.AddWithValue("@phone", newVolunteer.getPhone());
        insert.Parameters.AddWithValue("@DoB", newVolunteer.getDoB());
        insert.Parameters.AddWithValue("@emergencyFName", newVolunteer.getEmergencyFirstName());
        insert.Parameters.AddWithValue("@emergencyLName", newVolunteer.getEmergencyLastName());
        insert.Parameters.AddWithValue("@emergencyEmail", newVolunteer.getEmergencyEmail());
        insert.Parameters.AddWithValue("@emergencyPhone", newVolunteer.getEmergencyPhone());
        insert.Parameters.AddWithValue("@relationship", newVolunteer.getRelationship());

        insert.ExecuteNonQuery();

        sc.Close();

        // return to logIn page if successful
        MessageBox.Show("Success! Your Account has been created... You may now log in");
        Response.Redirect("Index.aspx");
    }
}