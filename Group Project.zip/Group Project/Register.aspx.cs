﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
// Change Framework version to 4.0.0 to import reference below
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Data.Entity;


public partial class Register : System.Web.UI.Page
{
    SqlConnection sc = new SqlConnection();

    protected void Page_Load(object sender, EventArgs e)
    {
        // Connect to DataBase
        try
        {
            sc.ConnectionString = @"Server=LAPTOP-PHM83N4S\sqlexpress;Database=GroupProject;Trusted_Connection=Yes;";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error" + ex.Message);
        }
    }
    protected void btnRegister_ServerClick(object sender, EventArgs e)
    {
        // create variables 
        String fname = Request.Form["txtFirstName"];
        String lname = Request.Form["txtLastName"];
        String email = Request.Form["txtEmail"];
        String password = Request.Form["txtPassword"];
        String confirmPass = Request.Form["txtConfirmPassword"];
     

        // NOTE: Have not created variables for medical information section
        
        // Test if email is entered in valid format
        if (!email.Contains("@"))
        {
            MessageBox.Show("Error: Invalid Email Entered");
            return;
        }
        // Variables to test if password contains upperCase, lowerCase, and Number
        bool containsUpper = false;
        bool containsLower = false;
        bool containsNumber = false;
        for (int i = 0; i < password.Length; i++)
        {
            if (char.IsUpper(password[i]))
            {
                containsUpper = true;
            }
            if (char.IsLower(password[i]))
            {
                containsLower = true;
            }
            if (char.IsNumber(password[i]))
            {
                containsNumber = true;
            }
        }
        // test if password meets requirements
        if (password.Length < 6 || containsUpper == false || containsLower == false || containsNumber == false)
        {
            MessageBox.Show("Error: Password does not meet requirements");
            return;
        }
        // test is passwords are the same
        if (password != confirmPass)
        {
            MessageBox.Show("Error: Passwords do not match - Please try again");
            return;
        }

        // create new Volunteer class object
       // Volunteer newVolunteer = new Volunteer(fname, lname, address, cityCounty, state, zipCode, phone, DoB, email, password, emergConFName, emergConLName, emergConPhone, emergConEmail, emergConRelationship);
        Volunteer newVolunteer = new Volunteer(fname, lname, password, email);

        // Use new Volunteer class object to insert into database
        sc.Open();
        SqlCommand insert = new SqlCommand();
        insert.Connection = sc;

        // check if email already exists in db
        SqlCommand checkEmail = new SqlCommand("SELECT COUNT(*) FROM MEMBER WHERE EMAIL = @email");
        checkEmail.Connection = sc;
        checkEmail.Parameters.AddWithValue("@email", email);
        int check = (int)checkEmail.ExecuteScalar();
        if (check != 0)
        {
            MessageBox.Show("Error - Email Already Exists");
            return;
        }

        
        
        byte[] salt = GenerateSalt(16);
        String salt1 = Convert.ToBase64String(salt);
        byte[] hash = GetHash(password, salt1);
       
        String password1 = Convert.ToBase64String(hash);
        
        
        // insert newVolunteer info into Volunteer db table
        insert.CommandText = "INSERT INTO Member (Volunteer, TeamLead, Administrator, Password_, FirstName, LastName, Email, Salt)";
        insert.CommandText += "VALUES (0, 0, 0, @password, @fname, @lname, @email, @salt)";

        // parameterize insert statement
        insert.Parameters.AddWithValue("@password", password1);
        insert.Parameters.AddWithValue("@fname", newVolunteer.getFName());
        insert.Parameters.AddWithValue("@lname", newVolunteer.getLName());
        insert.Parameters.AddWithValue("@email", newVolunteer.getEmail());
        insert.Parameters.AddWithValue("@salt", salt1);


        
        insert.ExecuteNonQuery();

        sc.Close();

        // return to logIn page if successful
        MessageBox.Show("Success! Your Account has been created... You may now log in");
        Response.Redirect("Index.aspx");
    }
     
   
    public static string GenerateSaltedSHA1(string plainTextString)
    {
        HashAlgorithm algorithm = new SHA1Managed();
        var saltBytes = GenerateSalt(4);
        var plainTextBytes = Encoding.ASCII.GetBytes(plainTextString);

        var plainTextWithSaltBytes = AppendByteArray(plainTextBytes, saltBytes);
        var saltedSHA1Bytes = algorithm.ComputeHash(plainTextWithSaltBytes);
        var saltedSHA1WithAppendedSaltBytes = AppendByteArray(saltedSHA1Bytes, saltBytes);

        return "{SSHA}" + Convert.ToBase64String(saltedSHA1WithAppendedSaltBytes);
    }
    private static byte[] GenerateSalt(int saltSize)
    {
        var rng = new RNGCryptoServiceProvider();
        var buff = new byte[saltSize];
        rng.GetBytes(buff);
        return buff;
    }
    public static byte[] GetHash(string password, string salt)
    {
        byte[] unhashedBytes = Encoding.Unicode.GetBytes(String.Concat(salt, password));

        SHA256Managed sha256 = new SHA256Managed();
        byte[] hashedBytes = sha256.ComputeHash(unhashedBytes);

        return hashedBytes;
    }

    private static byte[] AppendByteArray(byte[] byteArray1, byte[] byteArray2)
    {
        var byteArrayResult =
                new byte[byteArray1.Length + byteArray2.Length];

        for (var i = 0; i < byteArray1.Length; i++)
            byteArrayResult[i] = byteArray1[i];
        for (var i = 0; i < byteArray2.Length; i++)
            byteArrayResult[byteArray1.Length + i] = byteArray2[i];

        return byteArrayResult;
    }

}