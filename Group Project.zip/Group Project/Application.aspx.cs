﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
// Change Framework version to 4.0.0 to import reference below
using System.Windows.Forms;


public partial class Application : System.Web.UI.Page
{
    SqlConnection sc = new SqlConnection();

    protected void Page_Load(object sender, EventArgs e)
    {
        // Connect to DataBase
        try
        {
            sc.ConnectionString = @"Server=LocalHost\SQLEXPRESS;Database=GroupProject;Trusted_Connection=Yes;";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error" + ex.Message);
        }
        
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        // create variables
        String fname = txtFirstName.Text.ToString();
        String lname = txtLastName.Text.ToString();

        String address = txtAddress.Text.ToString();
        String city = txtCity.Text.ToString();
        String state = ddlState.SelectedItem.ToString();
        int zipCode = Convert.ToInt32(txtZip.Text);
        String phoneNumber = txtPhone.Text.ToString();
        int month = Convert.ToInt32(ddlMonth.SelectedItem.Value);
        int day = Convert.ToInt32(ddlDay.SelectedItem.Value);
        int year = Convert.ToInt32(ddlYear.SelectedItem.Value);

        // insert code to validate selected month and selected day are valid & ensure applicant is at least 18
        if (month == 0 || day == 0 || year == 0)
        {
            MessageBox.Show("Error: Must Enter Month, Day, and Year for Date of Birth");
                return;
        }
        String DoB = month + "/" + day + "/" + year;

        String email = txtEmail.Text.ToString();
        String password = txtPassword.Text.ToString();
        String confirmPass = txtConfirmPwd.Text.ToString();

        // Test if email is entered in valid format
        if (!email.Contains("@"))
        {
            MessageBox.Show("Error: Invalid Email Entered");
            return;
        }

        // Variables to test if password contains upperCase, lowerCase, and Number
        bool containsUpper = false;
        bool containsLower = false;
        bool containsNumber = false;
        for (int i = 0; i < password.Length; i++)
        {
            if (char.IsUpper(password[i]))
            {
                containsUpper = true;
            }
            if (char.IsLower(password[i]))
            {
                containsLower = true;
            }
            if (char.IsNumber(password[i]))
            {
                containsNumber = true;
            }
        }
        // test if password meets requirements
        if (password.Length < 6 || containsUpper==false || containsLower==false || containsNumber==false)
        {
            MessageBox.Show("Error: Password does not meet requirements");
            return;
        }
        // test is passwords are the same
        if (password != confirmPass)
        {
            MessageBox.Show("Error: Passwords do not match - Please try again");
            return;
        }

        String emergencyName = txtEmergencyName.Text.ToString();
        String emergencyPhone = txtEmergencyPhone.Text.ToString();
        String relationship = txtRelationship.Text.ToString();

        // insert email and password into Account db table after validation
        sc.Open();
        SqlCommand insert = new SqlCommand();
        insert.Connection = sc;
        

        // check if email already exists in db
        SqlCommand checkEmail = new SqlCommand("SELECT COUNT(*) FROM ACCOUNT WHERE EMAIL = @email");
        checkEmail.Connection = sc;
        checkEmail.Parameters.AddWithValue("@email", email);
        int check = (int)checkEmail.ExecuteScalar();
        if (check != 0)
        {
            MessageBox.Show("Error - Email Already Exists");
            return;
        }

        //insert.CommandText = "INSERT INTO ACCOUNT (email, password) VALUES (@email, @password)";
        //// parameterize insert statement
        //insert.Parameters.AddWithValue("@email", email);
        //insert.Parameters.AddWithValue("@password", password);
        //insert.ExecuteNonQuery();

        //// get accountID from database for newVolunteer object
        //insert.CommandText = "SELECT ACCOUNTID FROM ACCOUNT WHERE EMAIL = @email";
        //int accountID = (int)insert.ExecuteScalar();

        // create new Volunteer class object
        Volunteer newVolunteer = new Volunteer(fname, lname, address, city, state, zipCode, phoneNumber, DoB, email, password, emergencyName, emergencyPhone, relationship);

        // insert newVolunteer info into Volunteer db table
        insert.CommandText = "INSERT INTO Person (Password_, FirstName, LastName, Email, Phone, DateofBirth, Address, CityCounty, StateAbb, ZipCode, EmergencyContactFirstName, EmergencyContactLastName, EmergencyContactEmail, EmergencyContactPhone, EmergencyRelationship,)";
        insert.CommandText += "VALUES (@fname, @lname, @address, @city, @state, @zip, @phone, @DoB, @accountID, @EmergencyName, @EmergencyPhone, @Relationship)";
        // need DoB, remove login, address one line?, need countryabb?, emergency contact name/relationship

        // parameterize insert statement
        insert.Parameters.AddWithValue("@fname", newVolunteer.getFName());
        insert.Parameters.AddWithValue("@lname", newVolunteer.getLName());
        insert.Parameters.AddWithValue("@address", newVolunteer.getAddress());
        insert.Parameters.AddWithValue("@city", newVolunteer.getCity());
        insert.Parameters.AddWithValue("@state", newVolunteer.getState());
        insert.Parameters.AddWithValue("@zip", newVolunteer.getZip());
        insert.Parameters.AddWithValue("@phone", newVolunteer.getPhone());
        insert.Parameters.AddWithValue("@DoB", newVolunteer.getDoB());
        //insert.Parameters.AddWithValue("@accountID", newVolunteer.getAccountID());
        insert.Parameters.AddWithValue("@EmergencyName", newVolunteer.getEmergencyName());
        insert.Parameters.AddWithValue("@EmergencyPhone", newVolunteer.getEmergencyPhone());
        insert.Parameters.AddWithValue("@Relationship", newVolunteer.getRelationship());

        insert.ExecuteNonQuery();

        sc.Close();

        // return to logIn page if successful
        MessageBox.Show("Success! Your Account has been created.");
        Response.Redirect("LogIn.aspx");

    }
  
}