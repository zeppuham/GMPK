﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
// Change Framework version to 4.0.0 to import reference below
using System.Windows.Forms;

public partial class Application : System.Web.UI.Page
{
    SqlConnection sc = new SqlConnection();

    protected void Page_Load(object sender, EventArgs e)
    {
        // Connect to DataBase
        try
        {
            sc.ConnectionString = @"Server=LocalHost\SQLEXPRESS;Database=GroupProject;Trusted_Connection=Yes;";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error" + ex.Message);
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        // create variables
        String name = txtName.Text.ToString();
        int index = name.IndexOf(' ');
        String fname = name.Substring(0, index);
        String lname = name.Substring(name.IndexOf(' ')+1);

        String address = txtAddress.Text.ToString();
        String city = txtCity.Text.ToString();
        String state = ddlState.SelectedItem.ToString();
        int zipCode = Convert.ToInt32(txtZip.Text);
        String phoneNumber = txtPhone.Text.ToString();
        int month = Convert.ToInt32(ddlMonth.SelectedItem.Value);
        String day = ddlDay.SelectedItem.ToString();
        String year = ddlYear.SelectedItem.ToString();

        // insert code to validate selected month and selected day are valid & ensure applicant is at least 18
        String DoB = month + "/" + day + "/" + year;

        String email = txtEmail.Text.ToString();
        String password = txtPassword.Text.ToString();

        // insert email and password into Account db table after validation
        sc.Open();
        SqlCommand insert = new SqlCommand();
        insert.Connection = sc;

        // check if email already exists in db
        SqlCommand checkEmail = new SqlCommand("SELECT COUNT(*) FROM ACCOUNT WHERE EMAIL = '" + email + "'");
        checkEmail.Connection = sc;
        int check = (int)checkEmail.ExecuteScalar();
        if (check != 0)
        {
            MessageBox.Show("Error - Email Already Exists");
            return;
        }

        insert.CommandText = "INSERT INTO ACCOUNT (email, password) VALUES (@email, @password)";
        // parameterize insert statement
        insert.Parameters.AddWithValue("@email", email);
        insert.Parameters.AddWithValue("@password", password);
        insert.ExecuteNonQuery();

        // get accountID from database for newVolunteer object
        insert.CommandText = "SELECT ACCOUNTID FROM ACCOUNT WHERE EMAIL = '" + email + "'";
        int accountID = (int)insert.ExecuteScalar();

        // create new Volunteer class object
        Volunteer newVolunteer = new Volunteer(fname, lname, address, city, state, zipCode, phoneNumber, DoB, accountID, email, password);

        // insert newVolunteer info into Volunteer db table
        insert.CommandText = "INSERT INTO VOLUNTEER (FirstName, LastName, Address, City, State, ZipCode, Phone, DateofBirth, AccountID)";
        insert.CommandText += "VALUES (@fname, @lname, @address, @city, @state, @zip, @phone, @DoB, @accountID)";

        // parameterize insert statement
        insert.Parameters.AddWithValue("@fname", newVolunteer.getFName());
        insert.Parameters.AddWithValue("@lname", newVolunteer.getLName());
        insert.Parameters.AddWithValue("@address", newVolunteer.getAddress());
        insert.Parameters.AddWithValue("@city", newVolunteer.getCity());
        insert.Parameters.AddWithValue("@state", newVolunteer.getState());
        insert.Parameters.AddWithValue("@zip", newVolunteer.getZip());
        insert.Parameters.AddWithValue("@phone", newVolunteer.getPhone());
        insert.Parameters.AddWithValue("@DoB", newVolunteer.getDoB());
        insert.Parameters.AddWithValue("@accountID", newVolunteer.getAccountID());

        insert.ExecuteNonQuery();

        sc.Close();

        // return to logIn page if successful
        MessageBox.Show("Success! Your Account has been created.");
        Response.Redirect("LogIn.aspx");

    }
}