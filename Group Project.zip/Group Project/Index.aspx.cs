﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Security.Cryptography;
using System.IO;

// Change Framework version to 4.0.0 to import reference below
using System.Windows.Forms;

public partial class Index : System.Web.UI.Page
{
   SqlConnection sc = new SqlConnection();
   protected void Page_Load(object sender, EventArgs e)
   {
       // Connect to DataBase
       
       try
       {
           sc.ConnectionString = @"Server=LocalHost;Database=GroupProject;Trusted_Connection=Yes;";
       }
       catch (Exception ex)
       {
           MessageBox.Show("Error" + ex.Message);
       }
   }

   protected void btnLogin_ServerClick(object sender, EventArgs e)
   {
       sc.Open();

       String email = Request.Form["txtEmail"];
       String password = Request.Form["txtPassword"];

       // validate credentials
       bool authenticated = this.ValidateCredentials(email, password);
       bool rememberme = true;

       if (authenticated)
       {
      
       // get user ID
       SqlCommand user =  new SqlCommand("Select ID from member where email = @email");
       user.Connection = sc;
       user.Parameters.AddWithValue("@email",email);
       int userID = (int)user.ExecuteScalar();

       // determine if user is Applicant, Volunteer, TeamLead, or Administrator
       SqlCommand userType = new SqlCommand("Select Volunteer from member where ID = @ID");
       userType.Connection = sc;
       userType.Parameters.AddWithValue("@ID", userID);
       bool vol = (bool)userType.ExecuteScalar();

       userType = new SqlCommand("Select TeamLead  from member where ID = @ID");
       userType.Connection = sc;
       userType.Parameters.AddWithValue("@ID", userID);
       bool lead = (bool)(userType.ExecuteScalar());
       
       userType = new SqlCommand("Select Administrator from member where ID = @ID");
       userType.Connection = sc;
       userType.Parameters.AddWithValue("@ID", userID);
       bool admin = (bool)(userType.ExecuteScalar());
       
       
           // determine which page to redirect to depending on user type
           if (vol)
           {
               FormsAuthentication.RedirectFromLoginPage(email,rememberme);
               Response.Redirect("VolunteerPortal.aspx");
           }
           if (lead)
           {
               FormsAuthentication.RedirectFromLoginPage(email,rememberme);
               Response.Redirect("LeadPortal.aspx");
           }
           if (admin)
           {
               FormsAuthentication.RedirectFromLoginPage(email,rememberme);
               Response.Redirect("AdminPortal.aspx");
           }
           else
           {
               FormsAuthentication.RedirectFromLoginPage(email,rememberme);
               Response.Redirect("ApplicantPortal.aspx");
           }
       }
       else
       {
           MessageBox.Show("Incorrect Email/Password.. please try again");
           return;
       }
       sc.Close();
   }

       // methods to validate credentials 
    private bool ValidateCredentials(string email, string password)
    {
        bool returnValue = false;
        SqlConnection conn = null;

            try
            {
                string sql = "select count(*) from member where email = @email and password_ = @password";

                conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GroupProject"].ConnectionString);
                SqlCommand cmd = new SqlCommand(sql, conn);

                SqlParameter user = new SqlParameter();
                user.ParameterName = "@email";
                user.Value = email.Trim();
                cmd.Parameters.Add(user);

                SqlParameter pass = new SqlParameter();
                pass.ParameterName = "@password";
                pass.Value = password.Trim();
                cmd.Parameters.Add(pass);

                conn.Open();

                int count = (int)cmd.ExecuteScalar();

                if (count > 0) returnValue = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (conn != null) conn.Close();
            }
   
        return returnValue;
        
    }

}