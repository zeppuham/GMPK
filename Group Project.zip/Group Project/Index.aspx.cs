﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using System.Security.Cryptography;
using System.IO;
// Change Framework version to 4.0.0 to import reference below
using System.Windows.Forms;

public partial class Index : System.Web.UI.Page
{
   SqlConnection sc = new SqlConnection();
   protected void Page_Load(object sender, EventArgs e)
   {
       // Connect to DataBase
       try
       {
           sc.ConnectionString = @"Server=LocalHost\SQLEXPRESS;Database=GroupProject;Trusted_Connection=Yes;";
       }
       catch (Exception ex)
       {
           MessageBox.Show("Error" + ex.Message);
       }
   }

   protected void btnLogin_ServerClick(object sender, EventArgs e)
   {
       String email = Request.Form["txtEmail"];
       String password = Request.Form["txtPassword"];

       // validate credentials
       bool authenticated = this.ValidateCredentials(email, password);
       bool rememberme = false;

       if (authenticated)
       {
           FormsAuthentication.RedirectFromLoginPage(email,rememberme);
           Response.Redirect("Home.aspx");
       }
       else
       {
           MessageBox.Show("Incorrect Email/Password.. please try again");
           return;
       }
   }
       // methods to validate credentials 
    private bool ValidateCredentials(string email, string password)
    {
        bool returnValue = false;
        SqlConnection conn = null;

            try
            {
                string sql = "select count(*) from person where email = @email and password_ = @password";

                conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GroupProject"].ConnectionString);
                SqlCommand cmd = new SqlCommand(sql, conn);

                SqlParameter user = new SqlParameter();
                user.ParameterName = "@email";
                user.Value = email.Trim();
                cmd.Parameters.Add(user);

                SqlParameter pass = new SqlParameter();
                pass.ParameterName = "@password";
                pass.Value = password.Trim();
                cmd.Parameters.Add(pass);

                conn.Open();

                int count = (int)cmd.ExecuteScalar();

                if (count > 0) returnValue = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (conn != null) conn.Close();
            }
   
        return returnValue;
        
    }

}